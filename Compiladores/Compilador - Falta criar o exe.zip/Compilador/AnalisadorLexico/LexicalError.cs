﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core;

namespace AnalisadorLexico
{
    public class LexicalError : AnalysisError
    {
		private int linha;
		private int position;
		private string strToken;

		public LexicalError(String msg, int linha, int position, string token): base(msg, null)
        {
			this.linha = linha;
			this.strToken = token;
			this.position = position;
        }

		public override String ToString()
		{
			return string.Format(base.Message, this.linha + "" , position + "", strToken);
		}
	}

}

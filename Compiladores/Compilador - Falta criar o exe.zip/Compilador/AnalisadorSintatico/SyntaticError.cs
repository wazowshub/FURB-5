﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core;
using AnalisadorLexico;

namespace AnalisadorSintatico
{
    public class SyntaticError : AnalysisError
	{
		public SyntaticError(String msg, Token pToken) : base(msg, pToken)
		{
		}

		public override string ToString()
		{
			return String.Format(base.Message,token.getTipo(),token.getLinha(),token.getPosition(),token.getLexeme());
		}
	}

}

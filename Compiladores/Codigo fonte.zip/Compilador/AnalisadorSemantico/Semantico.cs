﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Core;
using AnalisadorLexico;

namespace AnalisadorSemantico
{
	public class Semantico : Constants
	{
		public void executeAction(int action, Token token)
		{
			Console.WriteLine("Ação #"+action+", Token: "+token);
		}
	}
}

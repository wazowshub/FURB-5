﻿using System;
using AnalisadorLexico;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Core
{
    public class AnalysisError : Exception
    {
		protected Token token;

        public AnalysisError(String msg, Token pToken): base(msg)
        {
			token = pToken;
        }
    }

}
